import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;

public class CLHLock implements Lock{
    AtomicReference<QNode> tail;
    ThreadLocal<QNode> myPred;
    ThreadLocal<QNode> myNode;

    public Condition newCondition(){
        final Condition c = newCondition();
        return c;  
    }
    public void lockInterruptibly(){
    
    }
    public boolean tryLock(){
      return true;
    }
    public boolean tryLock(long time, TimeUnit unit){
      return true;
    }
    public CLHLock() {
        tail = new AtomicReference<QNode>(new QNode());
        myNode = new ThreadLocal<QNode>() {
        protected QNode initialValue() {
        return new QNode();
    }
    };
        myPred = new ThreadLocal<QNode>() {
        protected QNode initialValue() {
        return null;
        }
    };
    }
    public void lock() {
        QNode qnode = myNode.get();
        qnode.locked = true;
        QNode pred = tail.getAndSet(qnode);
        myPred.set(pred);
    while (pred.locked) {}
    }
    public void unlock() {
        QNode qnode = myNode.get();
        qnode.locked = false;
        myNode.set(myPred.get());
    }
    class QNode {
      volatile boolean locked = false;    
    }
    }