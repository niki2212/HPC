Nikhita Rapolu
SE20UCSE115

---------------------------------------------------------------
Assignment 7

Contains three different lock implementations and a design file. The lock implementations are as follows:

Array Based Queue
CLS Queue Lock
MCS Queue Lock
To use any of these locks, you need to uncomment the desired lock implementation in the design file.
The throughput decreases as the number of threads increase and the duration is not modified.
Adding all the operations of the threads will give the final counter value.

To run the file:
javac Design.java
java Design 4 1000

The arguments are number of threads and the duration in milliseconds