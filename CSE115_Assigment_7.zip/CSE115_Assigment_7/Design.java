import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;

public class Design {
    public static AtomicInteger count = new AtomicInteger();

    private static ALock lock = new ALock(16);
    // private static CLHLock lock = new CLHLock();
    // private static MCSLock lock = new MCSLock();

    static long start;
    static int time;

    public static void main(String[] args) {
        int no_of_threads = Integer.parseInt(args[0]);
        time = Integer.parseInt(args[1]);
        
        Thread[] th = new Thread[no_of_threads];           
        for (int i = 0; i < no_of_threads; i++) {
            th[i] = new Incrementer();
        }

        start = System.currentTimeMillis();            
        for (int i = 0; i < no_of_threads; i++) {    
            th[i].start();
        }

        try {
            for (int i = 0; i < no_of_threads; i++) {
                th[i].join();
            }
        } catch (InterruptedException e) {
            System.out.println(e);
        }

        float throughput = count.get() / (float) time;            
        System.out.println("Number of Threads = " + no_of_threads + " Counter = " + count + " Throughput = " + throughput);
    }

    private static class Incrementer extends Thread {            
        private int opsCount = 0;

        public void run() {
            long end = System.currentTimeMillis();
            for (; end - start <= time;) {
                lock.lock();
                count.incrementAndGet();
                opsCount++;
                lock.unlock();
                end = System.currentTimeMillis();
            }
            System.out.println("Thread " + this.getId() + " completed " + opsCount + " operations.");
        }
    }
}
