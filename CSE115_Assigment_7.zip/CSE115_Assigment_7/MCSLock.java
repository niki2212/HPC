import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.TimeUnit;

public class MCSLock implements Lock {
AtomicReference<QNode> tail;
ThreadLocal<QNode> myNode;
public MCSLock() {
    tail = new AtomicReference<QNode>(null);
    myNode = new ThreadLocal<QNode>() {
    protected QNode initialValue() {
    return new QNode();
    }
  };
}

public Condition newCondition(){
  final Condition c = newCondition();
  return c;  
}
public void lockInterruptibly(){

}
public boolean tryLock(){
return true;
}
public boolean tryLock(long time, TimeUnit unit){
return true;
}
public void lock() {
    QNode qnode = myNode.get();
    QNode pred = tail.getAndSet(qnode);
    if (pred != null) {
    qnode.locked = true;
    pred.next = qnode;
    while (qnode.locked) {}
    }
}
public void unlock() {
QNode qnode = myNode.get();
if (qnode.next == null) {
if (tail.compareAndSet(qnode, null))
return;
while (qnode.next == null) {}
}
qnode.next.locked = false;
qnode.next = null;
 }
class QNode {
volatile boolean locked = false;
volatile QNode next = null;
}
}