import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.TimeUnit;

public class ALock implements Lock{
    ThreadLocal<Integer> mySlotIndex = new ThreadLocal<Integer> (){
    protected Integer initialValue() {
        return 0;
    }
};
public Condition newCondition(){
    final Condition c = newCondition();
    return c;  
}
public void lockInterruptibly(){

}
public boolean tryLock(){
  return true;
}
public boolean tryLock(long time, TimeUnit unit){
  return true;
}
AtomicInteger tail;
volatile boolean[] flag;
int size;
public ALock(int capacity) {
    size = capacity;
    tail = new AtomicInteger(0);
    flag = new boolean[capacity];
    flag[0] = true;
}
public void lock() {
    int slot = tail.getAndIncrement() % size;
    mySlotIndex.set(slot);
    while (!flag[slot]) {};
}
public void unlock() {
    int slot = mySlotIndex.get();
    flag[slot] = false;
    flag[(slot + 1) % size] = true;
}
}