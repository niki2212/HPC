# MATRIX MULTIPLICATION

## PROJECT MADE BY:
	1. Gauransh Khurana - SE20UCAM041
	2. Karthik MVS - SE20UCAM060
	3. Nikhita Rapolu - SE20UCSE115
	4. Niharika Kakumanu - SE20UCSE114
	5. Neethu Vangapalli - SE20UCSE110

The zip file contains the following files/Folders:

1. Shell script named "Assignment1.sh"
2. C file named "Assignment1.c"
3. 1 Folder Named "Scripts_Graph" containing following subfolders/files:
	A. 12 shell Files for creating the appropriate graphs
	B. 12 PDF Files Containing 144 graphs in total (Each PDf has a different time-taken scale)

To run the shell script
Run the following in terminal:
	
	chmod u+x Assignment1.sh
	./Assignment1.sh


The shell script "Assignment1.sh" has 2 parts: 'Constant Matrix Size' and 'Constant Threads'.
The script loops through all possible combinations of threads, matrix sizes, block sizes and transpose/non-transpose.
It passes those values as an argument to the C executable

The C file contains the code for finding time taken to calculate different powers of matrix A.
It accepts the following arguments: 
	A. Number of Threads
	B. Matrix Size
	C. Block Size
	D. Transpose/Non-transpose
	E. Power (Always 16)

The various functions inside the C program find the time taken to find A^2, A^3...etc depending on the arguments.
It loops through that same function 5 times, and then takes their average to obtain a better approximation.

In the end, it prints the time taken for A^2, A^3, A^4...A^{16}

The shell script, in return, takes that output and stores the data in ".dat" file to plot the graphs.


You can run each of the shell scripts inside "Scripts_Graphs" individually using the command:
	gnuplot filename.sh

The graphs contain No. of threads or Matrix sizes on x axis and Time taken on y axis with 15 lines describing the power of A.
