set term pdf size 10,8
set output "Const_Thread_10.pdf"

set xtics (512, 1024, 2048) font "Bold,10" offset 0, graph 0.01
set ytics font "Bold,7"

set xlabel "Number of Threads" font "Bold,12" offset 0, 0.8
set ylabel "Time Taken" font "Bold,12" offset 3,0

set key at screen 0.95,0.95 font ",15" vertical sample 0.4 spacing 0.3 width 0.5 height 1.0 maxrows 1

set multiplot layout 4, 3
#------------------------------------------------------------------------------------------------------------------
set title "OMM" font "Bold,15" offset -1.0,-3.5
set size 0.33,0.2

set yrange [0:40]

plot "./ConstThread/ConstThread-10-1-1.dat" using 1:2 title "A^2" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-1-1.dat" using 1:3 title "A^3" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-1-1.dat" using 1:4 title "A^4" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-1-1.dat" using 1:5 title "A^5" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-1-1.dat" using 1:6 title "A^6" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-1-1.dat" using 1:7 title "A^7" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-1-1.dat" using 1:8 title "A^8" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-1-1.dat" using 1:9 title "A^9" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-1-1.dat" using 1:10 title "A^{10}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-1-1.dat" using 1:11 title "A^{11}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-1-1.dat" using 1:12 title "A^{12}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-1-1.dat" using 1:13 title "A^{13}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-1-1.dat" using 1:14 title "A^{14}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-1-1.dat" using 1:15 title "A^{15}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-1-1.dat" using 1:16 title "A^{16}" with linespoint lw 2 ps 0.25
unset yrange
#------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------
set title "BMM - Block Size 4" font "Bold,15" offset -1.0,-3.5
set size 0.33,0.2

set yrange [0:40]

plot "./ConstThread/ConstThread-10-4-1.dat" using 1:2 title "A^2" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-4-1.dat" using 1:3 title "A^3" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-4-1.dat" using 1:4 title "A^4" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-4-1.dat" using 1:5 title "A^5" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-4-1.dat" using 1:6 title "A^6" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-4-1.dat" using 1:7 title "A^7" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-4-1.dat" using 1:8 title "A^8" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-4-1.dat" using 1:9 title "A^9" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-4-1.dat" using 1:10 title "A^{10}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-4-1.dat" using 1:11 title "A^{11}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-4-1.dat" using 1:12 title "A^{12}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-4-1.dat" using 1:13 title "A^{13}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-4-1.dat" using 1:14 title "A^{14}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-4-1.dat" using 1:15 title "A^{15}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-4-1.dat" using 1:16 title "A^{16}" with linespoint lw 2 ps 0.25
unset yrange
#------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------
set title "BMM - Block Size 8" font "Bold,15" offset -1.0,-3.5
set size 0.33,0.2

set yrange [0:40]

plot "./ConstThread/ConstThread-10-8-1.dat" using 1:2 title "A^2" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-8-1.dat" using 1:3 title "A^3" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-8-1.dat" using 1:4 title "A^4" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-8-1.dat" using 1:5 title "A^5" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-8-1.dat" using 1:6 title "A^6" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-8-1.dat" using 1:7 title "A^7" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-8-1.dat" using 1:8 title "A^8" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-8-1.dat" using 1:9 title "A^9" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-8-1.dat" using 1:10 title "A^{10}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-8-1.dat" using 1:11 title "A^{11}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-8-1.dat" using 1:12 title "A^{12}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-8-1.dat" using 1:13 title "A^{13}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-8-1.dat" using 1:14 title "A^{14}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-8-1.dat" using 1:15 title "A^{15}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-8-1.dat" using 1:16 title "A^{16}" with linespoint lw 2 ps 0.25
unset yrange
#------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------
set title "BMM - Block Size 16" font "Bold,15" offset -1.0,-3.5
set size 0.33,0.2

set yrange [0:40]

plot "./ConstThread/ConstThread-10-16-1.dat" using 1:2 title "A^2" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-16-1.dat" using 1:3 title "A^3" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-16-1.dat" using 1:4 title "A^4" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-16-1.dat" using 1:5 title "A^5" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-16-1.dat" using 1:6 title "A^6" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-16-1.dat" using 1:7 title "A^7" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-16-1.dat" using 1:8 title "A^8" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-16-1.dat" using 1:9 title "A^9" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-16-1.dat" using 1:10 title "A^{10}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-16-1.dat" using 1:11 title "A^{11}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-16-1.dat" using 1:12 title "A^{12}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-16-1.dat" using 1:13 title "A^{13}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-16-1.dat" using 1:14 title "A^{14}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-16-1.dat" using 1:15 title "A^{15}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-16-1.dat" using 1:16 title "A^{16}" with linespoint lw 2 ps 0.25
unset yrange
#------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------
set title "BMM - Block Size 32" font "Bold,15" offset -1.0,-3.5
set size 0.33,0.2

set yrange [0:40]

plot "./ConstThread/ConstThread-10-32-1.dat" using 1:2 title "A^2" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-32-1.dat" using 1:3 title "A^3" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-32-1.dat" using 1:4 title "A^4" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-32-1.dat" using 1:5 title "A^5" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-32-1.dat" using 1:6 title "A^6" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-32-1.dat" using 1:7 title "A^7" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-32-1.dat" using 1:8 title "A^8" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-32-1.dat" using 1:9 title "A^9" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-32-1.dat" using 1:10 title "A^{10}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-32-1.dat" using 1:11 title "A^{11}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-32-1.dat" using 1:12 title "A^{12}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-32-1.dat" using 1:13 title "A^{13}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-32-1.dat" using 1:14 title "A^{14}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-32-1.dat" using 1:15 title "A^{15}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-32-1.dat" using 1:16 title "A^{16}" with linespoint lw 2 ps 0.25
unset yrange
#------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------
set title "BMM - Block Size 64" font "Bold,15" offset -1.0,-3.5
set size 0.33,0.2

set yrange [0:40]

plot "./ConstThread/ConstThread-10-64-1.dat" using 1:2 title "A^2" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-64-1.dat" using 1:3 title "A^3" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-64-1.dat" using 1:4 title "A^4" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-64-1.dat" using 1:5 title "A^5" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-64-1.dat" using 1:6 title "A^6" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-64-1.dat" using 1:7 title "A^7" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-64-1.dat" using 1:8 title "A^8" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-64-1.dat" using 1:9 title "A^9" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-64-1.dat" using 1:10 title "A^{10}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-64-1.dat" using 1:11 title "A^{11}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-64-1.dat" using 1:12 title "A^{12}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-64-1.dat" using 1:13 title "A^{13}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-64-1.dat" using 1:14 title "A^{14}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-64-1.dat" using 1:15 title "A^{15}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-64-1.dat" using 1:16 title "A^{16}" with linespoint lw 2 ps 0.25
unset yrange
#------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------
set title "OMM Transpose" font "Bold,15" offset -1.0,-3.5
set size 0.33,0.2

set yrange [0:40]

plot "./ConstThread/ConstThread-10-1-2.dat" using 1:2 title "A^2" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-1-2.dat" using 1:3 title "A^3" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-1-2.dat" using 1:4 title "A^4" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-1-2.dat" using 1:5 title "A^5" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-1-2.dat" using 1:6 title "A^6" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-1-2.dat" using 1:7 title "A^7" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-1-2.dat" using 1:8 title "A^8" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-1-2.dat" using 1:9 title "A^9" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-1-2.dat" using 1:10 title "A^{10}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-1-2.dat" using 1:11 title "A^{11}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-1-2.dat" using 1:12 title "A^{12}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-1-2.dat" using 1:13 title "A^{13}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-1-2.dat" using 1:14 title "A^{14}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-1-2.dat" using 1:15 title "A^{15}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-1-2.dat" using 1:16 title "A^{16}" with linespoint lw 2 ps 0.25
unset yrange
#------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------
set title "BMMT - Block Size 4" font "Bold,15" offset -1.0,-3.5
set size 0.33,0.2

set yrange [0:40]

plot "./ConstThread/ConstThread-10-4-2.dat" using 1:2 title "A^2" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-4-2.dat" using 1:3 title "A^3" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-4-2.dat" using 1:4 title "A^4" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-4-2.dat" using 1:5 title "A^5" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-4-2.dat" using 1:6 title "A^6" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-4-2.dat" using 1:7 title "A^7" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-4-2.dat" using 1:8 title "A^8" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-4-2.dat" using 1:9 title "A^9" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-4-2.dat" using 1:10 title "A^{10}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-4-2.dat" using 1:11 title "A^{11}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-4-2.dat" using 1:12 title "A^{12}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-4-2.dat" using 1:13 title "A^{13}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-4-2.dat" using 1:14 title "A^{14}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-4-2.dat" using 1:15 title "A^{15}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-4-2.dat" using 1:16 title "A^{16}" with linespoint lw 2 ps 0.25
unset yrange
#------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------
set title "BMMT - Block Size 8" font "Bold,15" offset -1.0,-3.5
set size 0.33,0.2

set yrange [0:40]

plot "./ConstThread/ConstThread-10-8-2.dat" using 1:2 title "A^2" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-8-2.dat" using 1:3 title "A^3" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-8-2.dat" using 1:4 title "A^4" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-8-2.dat" using 1:5 title "A^5" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-8-2.dat" using 1:6 title "A^6" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-8-2.dat" using 1:7 title "A^7" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-8-2.dat" using 1:8 title "A^8" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-8-2.dat" using 1:9 title "A^9" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-8-2.dat" using 1:10 title "A^{10}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-8-2.dat" using 1:11 title "A^{11}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-8-2.dat" using 1:12 title "A^{12}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-8-2.dat" using 1:13 title "A^{13}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-8-2.dat" using 1:14 title "A^{14}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-8-2.dat" using 1:15 title "A^{15}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-8-2.dat" using 1:16 title "A^{16}" with linespoint lw 2 ps 0.25
unset yrange
#------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------
set title "BMMT - Block Size 16" font "Bold,15" offset -1.0,-3.5
set size 0.33,0.2

set yrange [0:40]

plot "./ConstThread/ConstThread-10-16-2.dat" using 1:2 title "A^2" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-16-2.dat" using 1:3 title "A^3" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-16-2.dat" using 1:4 title "A^4" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-16-2.dat" using 1:5 title "A^5" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-16-2.dat" using 1:6 title "A^6" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-16-2.dat" using 1:7 title "A^7" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-16-2.dat" using 1:8 title "A^8" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-16-2.dat" using 1:9 title "A^9" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-16-2.dat" using 1:10 title "A^{10}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-16-2.dat" using 1:11 title "A^{11}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-16-2.dat" using 1:12 title "A^{12}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-16-2.dat" using 1:13 title "A^{13}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-16-2.dat" using 1:14 title "A^{14}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-16-2.dat" using 1:15 title "A^{15}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-16-2.dat" using 1:16 title "A^{16}" with linespoint lw 2 ps 0.25
unset yrange
#------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------
set title "BMMT - Block Size 32" font "Bold,15" offset -1.0,-3.5
set size 0.33,0.2

set yrange [0:40]

plot "./ConstThread/ConstThread-10-32-2.dat" using 1:2 title "A^2" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-32-2.dat" using 1:3 title "A^3" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-32-2.dat" using 1:4 title "A^4" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-32-2.dat" using 1:5 title "A^5" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-32-2.dat" using 1:6 title "A^6" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-32-2.dat" using 1:7 title "A^7" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-32-2.dat" using 1:8 title "A^8" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-32-2.dat" using 1:9 title "A^9" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-32-2.dat" using 1:10 title "A^{10}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-32-2.dat" using 1:11 title "A^{11}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-32-2.dat" using 1:12 title "A^{12}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-32-2.dat" using 1:13 title "A^{13}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-32-2.dat" using 1:14 title "A^{14}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-32-2.dat" using 1:15 title "A^{15}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-32-2.dat" using 1:16 title "A^{16}" with linespoint lw 2 ps 0.25
unset yrange
#------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------
set title "BMMT - Block Size 64" font "Bold,15" offset -1.0,-3.5
set size 0.33,0.2

set yrange [0:40]

plot "./ConstThread/ConstThread-10-64-2.dat" using 1:2 title "A^2" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-64-2.dat" using 1:3 title "A^3" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-64-2.dat" using 1:4 title "A^4" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-64-2.dat" using 1:5 title "A^5" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-64-2.dat" using 1:6 title "A^6" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-64-2.dat" using 1:7 title "A^7" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-64-2.dat" using 1:8 title "A^8" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-64-2.dat" using 1:9 title "A^9" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-64-2.dat" using 1:10 title "A^{10}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-64-2.dat" using 1:11 title "A^{11}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-64-2.dat" using 1:12 title "A^{12}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-64-2.dat" using 1:13 title "A^{13}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-64-2.dat" using 1:14 title "A^{14}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-64-2.dat" using 1:15 title "A^{15}" with linespoint lw 2 ps 0.25,\
"./ConstThread/ConstThread-10-64-2.dat" using 1:16 title "A^{16}" with linespoint lw 2 ps 0.25
unset yrange
#------------------------------------------------------------------------------------------------------------------
unset multiplot

