#include<omp.h>
#include<stdio.h>
#include<sys/time.h>
#include<time.h>
#include<stdlib.h>

double **A; //Original Matrix
double **temp; //Will store the intermediate values of A, A2, A3 etc...
double **ans;

double elapsed[5][15];
double transposing_time=0;

struct timeval tv[16], tv_tt1, tv_tt2;
struct timezone tz;

void non_transpose_mult_omm(int iteration_num, int power, int size)
{
	int i, j, k, l;
	gettimeofday(&tv[0], &tz); //Marks the initial time

	for(l = 1; l<power; ++l) //Loops through power specified
	{
		for(int i = 0; i < size; i++) //Making ans matrix equal to 0
			for(int j = 0; j<size; j++)
				ans[i][j] = 0;

		#pragma omp parallel for private(i, j, k) shared(A, ans) //Parallel Programming
		for (i = 0; i < size; i++)
		{
			for(j = 0; j < size; j++)
			{
				for(k = 0; k<size; k++)
				{
					ans[i][j] += temp[i][k]*A[k][j];
				}
			}
		}

		for(int i = 0; i < size; i++) //Making temp equal to current ans(A2, A3 etc...)
			for(int j = 0; j<size; j++)
				temp[i][j] = ans[i][j];

		gettimeofday(&tv[l], &tz); //Marks the time taken to increase power of A by 1
		elapsed[iteration_num][l-1] = (double) (tv[l].tv_sec-tv[0].tv_sec) + (double) (tv[l].tv_usec-tv[0].tv_usec) * 1.e-6;
	}

}

void transpose_mult_omm(int iteration_num, int power, int size)
{
	int i, j, k, l;
	gettimeofday(&tv[0], &tz); //Marks the initial time

	for(l = 1; l<power; ++l) //Loops through power specified
	{
		for(int i = 0; i < size; i++) //Making ans matrix equal to 0
			for(int j = 0; j<size; j++)
				ans[i][j] = 0;

		#pragma omp parallel for private(i, j, k) shared(A, ans) //Parallel Programming
		for (i = 0; i < size; i++)
		{
			for(j = 0; j < size; j++)
			{
				for(k = 0; k<size; k++)
				{
					ans[i][j] += temp[i][k]*A[j][k];
				}
			}
		}

		for(int i = 0; i < size; i++) //Making temp equal to current ans(A2, A3 etc...)
			for(int j = 0; j<size; j++)
				temp[i][j] = ans[i][j];

		gettimeofday(&tv[l], &tz); //Marks the time taken to increase power of A by 1
		elapsed[iteration_num][l-1] = (double) (tv[l].tv_sec-tv[0].tv_sec) + (double) (tv[l].tv_usec-tv[0].tv_usec) * 1.e-6;
	}

}

void mult_blocks (int i, int j, int k, int block_size)
{
	int m, n, o;
	// #pragma omp parallel for private(m, n, o) shared(ans)
	for(m = 0;m<block_size;m++)
	{
		for(n = 0;n<block_size;n++)
		{
			for(o = 0;o<block_size;o++)
			{
				// #pragma omp critical
					ans[i + m][j + n] += temp[i + m][k + o]*A[k + o][j + n];
			}
		}
	}
}

void mult_blocks_transpose (int i, int j, int k, int block_size)
{
	int m, n, o;
	for(m = 0;m<block_size;m++)
	{
		for(n = 0;n<block_size;n++)
		{
			for(o = 0;o<block_size;o++)
			{
					ans[i + m][j + n] += temp[i + m][k + o]*A[j + n][k + o];
			}
		}
	}
}

void bmm(int iteration_num, int power, int size, int block_size, int transposed)
{
	int i, j, k, l, m;
	gettimeofday(&tv[0], &tz); //Marks the initial time

	for(l = 1; l<power; ++l) //Loops through power specified
	{
		for(int i = 0; i < size; i++) //Making ans matrix equal to 0
			for(int j = 0; j<size; j++)
				ans[i][j] = 0;

		#pragma omp parallel for private(i, j, k) shared(ans) //Parallel Programming
		for (i = 0; i < size; i+=block_size)
		{
			for(j = 0; j < size; j+=block_size)
			{
				for(k = 0; k<size; k+=block_size)
				{
					if(transposed == 1)
						mult_blocks(i,j,k,block_size);
					else
						mult_blocks_transpose(i,j,k,block_size);
				}
			}
		}

		for(int i = 0; i < size; i++) //Making temp equal to current ans(A2, A3 etc...)
			for(int j = 0; j<size; j++)
				temp[i][j] = ans[i][j];

		gettimeofday(&tv[l], &tz); //Marks the time taken to increase power of A by 1
		elapsed[iteration_num][l-1] = (double) (tv[l].tv_sec-tv[0].tv_sec) + (double) (tv[l].tv_usec-tv[0].tv_usec) * 1.e-6;
	}
}



int main(int argc, char*argv[])
{
	/*
		Argument 1 = number of threads
		Arg 2 = size of matrix
		Arg 3 = Block size (in case of OMM size == 1)
		Arg 4 = Transpose (if 1 not transposed else transposed)
		Arg 5 = to what power A is going to
	*/
	srand(time(0));
	int num_thread = atoi(argv[1]);
	int size = atoi(argv[2]);
	int block_size = atoi(argv[3]);
	int type = atoi(argv[4]);
	int n = atoi(argv[5]);
	omp_set_num_threads(num_thread);

	A = (double**)calloc(sizeof(double*), size);
	ans = (double**)calloc(sizeof(double*), size);
	temp = (double**)calloc(sizeof(double*), size);

	for (int i = 0; i < size; i++)
	{
		A[i] = (double*)calloc(sizeof(double), size);
		ans[i] = (double*)calloc(sizeof(double*), size);
		temp[i] = (double*)calloc(sizeof(double*), size);
	}

	for(int i = 0; i < size; i++)
	{
		for(int j = 0; j<size; j++)
		{
			A[i][j] = ((double)rand())/RAND_MAX;
			// printf("%.12lf ", A[i][j]); //Printing the matrix
		}
		// printf("\n"); //Printing the matrix
	}

	if (type == 1) //Not transpose
	{
		if(block_size == 1) //OMM
		{
			for(int i = 0; i<5; i++)
			{
				//Making temp equal to A matrix for a new iteration to take average
				for(int i = 0; i < size; i++)
					for(int j = 0; j<size; j++)
						temp[i][j] = A[i][j];
				non_transpose_mult_omm(i, n, size);
			}
		}
		else //BMM
		{
			for(int i = 0; i<5; i++)
			{
				//Making temp equal to A matrix for a new iteration to take average
				for(int i = 0; i < size; i++)
					for(int j = 0; j<size; j++)
						temp[i][j] = A[i][j];
				bmm(i, n, size,block_size, type);
			}
		}
	}
	else //Transpose
	{
		gettimeofday(&tv_tt1, &tz); //Marks the initial time for matrix transpose

		//Transposing A
		for(int i = 0;i<size;i++)
		{
			for(int j = i+1;j<size;j++)
			{
				double T = A[i][j];
				A[i][j] = A[j][i];
				A[j][i] = T;
			}
		}
		gettimeofday(&tv_tt2, &tz); //Marks the time taken to matrix transpose
		transposing_time = (double) (tv_tt2.tv_sec-tv_tt1.tv_sec) + (double) (tv_tt2.tv_usec-tv_tt1.tv_usec) * 1.e-6;


		for(int i = 0; i<5; i++)
		{
			//Making temp equal to A matrix for a new iteration to take average
			for(int i = 0; i < size; i++)
				for(int j = 0; j<size; j++)
					temp[i][j] = A[j][i];
			if(block_size == 1) //OMM
				transpose_mult_omm(i, n, size); //Calling function to multiply using transpose 
			else	//BMM
				bmm(i, n, size, block_size, type);
		}
	}
	printf("\t");
	double finalelapsed[15] = {}; //Average of all elapsed times
	for(int i = 0; i<15; i++)
	{
		for(int j = 0; j<5; j++)
		{
			finalelapsed[i] += elapsed[j][i];
		}
		finalelapsed[i]/=5;
		printf("%5.3lf\t", finalelapsed[i]+transposing_time); //Printing the elapsed times
	}
	printf("\n");

	// //Printing The Matrix
	// for(int i = 0; i < size; i++)
	// {
	// 	for(int j = 0; j<size; j++)
	// 	{
	// 		printf("%.12lf ", ans[i][j]);
	// 	}
	// 	printf("\n");
	// }
}
