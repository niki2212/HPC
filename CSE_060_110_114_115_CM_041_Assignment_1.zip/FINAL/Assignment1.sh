#Assignment 1 - HPC (SHELL SCRIPT)

#Constant Thread (Total 9)
#Number of Threads
mkdir "ConstThread"
Thread=1
while [ $Thread -le 16 ]
do
	#Ordinary/Block Matrix, block size = 1: for Ordinary, otherwise, 4, 8, 16, 32, 64
	BlockSize=1
	while [ $BlockSize -le 64 ]
	do
		if [ $BlockSize -eq 2 ]; #For Block size 2, Shouldn't exist
		then
			BlockSize=$(($BlockSize*2))
			continue
		fi

		#Non Transpose = 1, Transpose = 2
		Trans=1
		while [ $Trans -le 2 ]
		do

			#Size varying... 512, 1024, 2048
			MatSize=512
			while [ $MatSize -le 2048 ]
			do
				gcc -O3 Assignment1.c -o File -fopenmp
				echo -n $MatSize >> ./Scripts_Graph/ConstThread/ConstThread-$Thread-$BlockSize-$Trans.dat
				echo "Thread Num: $Thread, Block Size: $BlockSize, Transpose = $Trans, MatSize = $MatSize"
				./File $Thread $MatSize $BlockSize $Trans 16 >> ./Scripts_Graph/ConstThread/ConstThread-$Thread-$BlockSize-$Trans.dat

				MatSize=$(($MatSize*2))
			done
			Trans=$(($Trans+1))
		done
		BlockSize=$(($BlockSize*2))
	done

	if [ $Thread -eq 1 ]; #Thread 2 comes after Thread 1
	then
		Thread=$(($Thread+1))
	else
		Thread=$(($Thread+2))
	fi
done


# Constant Matrix Size (Total 3)
MatSize=512
mkdir "ConstMatSize"
while [ $MatSize -le 2048 ]
do
	#Ordinary/Block Matrix, block size = 1: for Ordinary, otherwise, 4, 8, 16, 32, 64
	BlockSize=1
	while [ $BlockSize -le 64 ]
	do
		if [ $BlockSize -eq 2 ]; #For Block size 2, Shouldn't exist
		then
			BlockSize=$(($BlockSize*2))
			continue
		fi

		#Non Transpose = 1, Transpose = 2
		Trans=1
		while [ $Trans -le 2 ]
		do
			#Number of Threads...varying from 1, 2, 4, 6, 8, 10, 12, 14, 16
			Thread=1
			while [ $Thread -le 16 ]
			do
				gcc -O3 Assignment1.c -o File -fopenmp
				echo -n $Thread >> ./Scripts_Graph/ConstMatSize/"ConstMatSize-$MatSize-$BlockSize-$Trans".dat
				echo "MatSize = $MatSize, Block Size: $BlockSize, Transpose = $Trans, Thread Num: $Thread"
				./File $Thread $MatSize $BlockSize $Trans 16 >> ./Scripts_Graph/ConstMatSize/"ConstMatSize-$MatSize-$BlockSize-$Trans".dat

				if [ $Thread -eq 1 ]; #Thread 2 comes after Thread 1
				then
					Thread=$(($Thread+1))
				else
					Thread=$(($Thread+2))
				fi
			done
			Trans=$(($Trans+1))
		done
		BlockSize=$(($BlockSize*2))
	done
	MatSize=$(($MatSize*2))
done
