NumThreads=1
while [ $NumThreads -le 16 ]
do
    Size=10
    while [ $Size -le 11 ]
    do
        echo "Number of threads: $NumThreads, Size: $Size"
        gcc MatrixCM.c -kO3 -o MatrixCM -fopenmp
        
        ./Merge $Size $NumThreads >> MatrixCM_Data.dat
        
        Size=$(($Size+1))
    done

    echo >> MatrixCM_Data.dat

    if [ $NumThreads -eq 1 ]; #Thread 2 comes after Thread 1
    then
        NumThreads=$(($NumThreads+1))
    else
        NumThreads=$(($NumThreads+2))
    fi
done