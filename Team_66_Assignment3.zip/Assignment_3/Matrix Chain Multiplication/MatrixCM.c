#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <omp.h>
#include <time.h>
#include<stdbool.h>
#include<string.h>
#include <sys/time.h>

#define min(a,b) (a>b?b:a)

unsigned long long int*** matrices;

void printParenthesis(int i, int j, int n, int *bracket, char name, int* p) //Print the order in which matrices are supposed to be multiplied
{
    if (i == j)
    {
        printf("%c%d", name, i);
        return;
    }

    printf("(");
    int xx = *((bracket+i*n)+j);
    printParenthesis(i, xx, n, bracket, name, p);
    printParenthesis(xx + 1, j, n, bracket, name, p);
    // temp = (int***)malloc(sizeof(int**)*n);
    // non_transpose_mult_omm(matrices[xx], matrices[xx+1], temp[xx], p[xx-1], p[xx], p[xx+1]);
    printf(")");
}

void non_transpose_mult_omm(unsigned long long int* A[], unsigned long long int* B[], unsigned long long int* C[], int a, int b, int c)
{
	int i, j, k;

    #pragma omp parallel for private(i, j, k) shared(A) //Parallel Programming
    for (i = 0; i < a; i++)
    {
        for(j = 0; j < c; j++)
        {
            for(k = 0; k < b; k++)
            {
                C[i][j] += A[i][k]*B[k][j];
            }
        }
    }

}

void matrixChainOrder(int *p, int n)
{
    unsigned long long int m[n][n];
    int bracket[n][n];

    for(int i = 0; i < n; i++)
    {
        for(int j = 0; j<n; j++)
        {
            m[i][j] = 0;
            bracket[i][j] = 0;
        }
    }
    int len,i,j,k;
    // #pragma omp parallel for shared(m)    
    for ( len = 2; len < n; len++) {
        // #pragma omp parallel for shared(m) schedule(dynamic)
        for (i = 1; i < n - len + 1; i++) {
            j = i + len - 1;
            m[i][j] = LLONG_MAX;

            // #pragma omp parallel for num_threads(1)
            for (k = i; k < j; k++) {
                unsigned long long int q = m[i][k] + m[k+1][j] + p[i-1]*p[k]*p[j];

                if (q < m[i][j]) {
                    m[i][j] = q;
                    bracket[i][j] = k;
                }
            }
        }
    }

    printf("Minimum number of multiplications is %lld\n", m[1][n-1]);
    //Print the order in which matrices are supposed to be miltiplied
    // printParenthesis(1, n-1, n, &bracket[0][0], 'A', p);
}
        

void fillmatrices(int*p, int n) //generates p matrices of sizes p[0]*p[1], p[1]*p[2] etc... with random values from 0 and 1
{
    matrices = (unsigned long long int***)malloc(sizeof(unsigned long long int**)*n);

    for(int i = 0; i<n; i++)
    {
        matrices[i] = (unsigned long long int**)malloc(sizeof(unsigned long long int*)*p[i]);
        for(int j = 0; j<p[i]; j++)
        {
            matrices[i][j] = (unsigned long long int*)malloc(sizeof(unsigned long long int)*p[i+1]);
            for(int k = 0; k<p[i+1]; k++)
            {
                matrices[i][j][k] = rand()%2; 
            }
        }
    }
} 


int main(int argc, char *argv[]) 
{

    if (argc != 3) 
    {
        printf("Usage: ./program_name num_matrices num_threads\n");
        exit(1);
    }

    srand(time(0));
    int n = atoi(argv[1]); //Number of Matrices
    int num_threads = atoi(argv[2]); //Number of threads to be used
    omp_set_num_threads(num_threads);
    int p[n];
    for (int i = 0; i <= n; i++) //p values are ranging from 1000 to 1099
    { 
        p[i] = (rand()%100+1000);
        // printf("%d ", p[i]);
    }
    printf("Number of Threads = %d, Number of Matrices = %d\n", num_threads, n);
    fillmatrices(p, n);

    double start, end;
    start = omp_get_wtime();

    matrixChainOrder(p, n+1);

    for(int i = 0; i < n-1; i++) //Multiplying matrices
    {
        unsigned long long int **temp;
        temp = (unsigned long long int**)malloc(sizeof(unsigned long long int*)*p[i]);
        for(int j = 0; j < p[i]; j++) //Making ans matrix equal to 0
        {
            temp[j] = (unsigned long long int*)malloc(sizeof(unsigned long long int)* p[i+2]);
            for(int k = 0; k<p[i+2]; k++)
            {
                temp[j][k] = 0;
            }
        }
        non_transpose_mult_omm(matrices[i], matrices[i+1], temp, p[i], p[i+1], p[i+2]);
        free(matrices[i]); 
        free(matrices[i+1]);
        matrices[i+1] = (unsigned long long int**)malloc(sizeof(unsigned long long int*)*p[i]);
        for(int j = 0; j < p[i]; j++)
        {
            matrices[i+1][j] = (unsigned long long int*)malloc(sizeof(unsigned long long int)*p[i+2]);
            for(int k = 0; k<p[i+2]; k++)
            {
                matrices[i+1][j][k] = temp[j][k];
            }
        }
        p[i+1] = p[i];
        free(temp);
    }
    end = omp_get_wtime();

    // printf("\n\nANSWER MATRIX = \n");
    // for(int j = 0; j<p[n-1]; j++)
    // {
    //     for(int k = 0; k<p[n]; k++)
    //     {
    //         printf("%lld\t\t\t", matrices[n-1][j][k]);
    //     }
    //     printf("\n");
    // }

    printf("Time in secs: %g\n\n", end - start);

    return 0;
}