#include<stdio.h>
#include<stdlib.h>


int main(int argc, char*argv[])
{
    int size1 = atoi(argv[1]);
    int size2 = atoi(argv[2]);
    int c = 0;
    int maxi = 0.1*size1*size2;
    for(int i = 0; i<size1; i++)
    {
        for(int j = 0; j<size2; j++)
        {
            if (c<maxi)
            {
                int temp = rand()%2;
                if (temp)
                    c++;
                printf("%d ", temp);
            }
            else 
                printf("0 ");
        }
        printf("\n");
    }
}
