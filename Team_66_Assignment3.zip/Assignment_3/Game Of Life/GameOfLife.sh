#We assume steps to be 10
Steps=10

NumThreads=1
while [ $NumThreads -le 16 ]
do
    Size1=1024
    while [ $Size1 -le 8192 ]
    do
        Size2=1024
        while [ $Size2 -le 8192 ]
        do
            echo "Row: $Size1, Column: $Size2, Number of threads: $NumThreads"
            gcc GOL_SeedGenerator.c -O3 -o SeedGenerator
            ./SeedGenerator $Size1 $Size2 >> SeedFile-$Size1-$Size2.dat #Generates Seed Files 
            gcc conway2.c -O3 -o Conway -fopenmp -w
            ./Conway "SeedFile-$Size1-$Size2.dat" $Size1 $Size2 $Steps "Answer-$Size1-$Size2.dat" $NumThreads >> TimeTaken.dat
            
            Size2=$(($Size2*2))
        done
        Size1=$(($Size1*2))
    done

    echo >> TimeTaken.dat

    if [ $NumThreads -eq 1 ]; #Thread 2 comes after Thread 1
    then
        NumThreads=$(($NumThreads+1))
    else
        NumThreads=$(($NumThreads+2))
    fi
done