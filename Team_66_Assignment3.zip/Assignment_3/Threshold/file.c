#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<omp.h>
#include<time.h>

int r,c,p;
int **M,**B;
FILE *readpointer,*writepointer;

int count[301];
int percentVal;

int imageGen(int x,int** M)
{
    int count = 0;
    for(int i = 0;i<r;i++)
    {
        for(int j = 0;j<c;j++)
        {
            if(M[i][j]>x)
                count++;
            if(count>percentVal)
                goto label;
        }
    }
    label:
    if(count>percentVal)
        return 0;
    else
        return 1;
}

int main(int argc, char* argv[])
{

    if(argc!=7)
    {
        printf("Use :./file r c <filename> p <filename> threads\n");
        exit(0);
    }
    
    r = atoi(argv[1]);
    c = atoi(argv[2]);
    p = atoi(argv[4]);
	int threads = atoi(argv[6]);
    M = (int**)malloc(sizeof(int*)*r);
    B = (int**)malloc(sizeof(int*)*r);

    for(int i = 0;i<r;i++)
    {
        M[i] = (int*)malloc(sizeof(int)*c);
        B[i] = (int*)malloc(sizeof(int)*c);
    }
    
    readpointer = fopen(argv[3],"r");
    if(readpointer == NULL)
        exit(0);

    omp_set_num_threads(threads);
    percentVal = (r*c*p)/100;
    for(int i = 0;i<r;i++)
        for(int j = 0;j<c;j++)
            fscanf(readpointer,"%d",&M[i][j]);
    fclose(readpointer);

    double start,end;
    start = omp_get_wtime();

    #pragma omp parallel for
    for(int i = 0;i<301;i++)
    {
        count[i] = imageGen(i,M);
        //printf("%d-%d\n",i,count[i]);
    }


    for(int i = 0;i<r;i++)
    {
        for(int j = 0;j<c;j++)
        {
            B[i][j] = count[M[i][j]];
            //printf("%d ",B[i][j]);
        }
        //printf("\n");
    }

    end = omp_get_wtime();
    printf("%g\n",end - start);

    writepointer = fopen(argv[5],"w");
    if(writepointer==NULL)
    {
        printf("Write error\n");
        exit(0);
    }
    for(int i=0;i<r;i++)
    {
        for(int j = 0;j<c;j++)
            fprintf(writepointer,"%d ",B[i][j]);
        fprintf(writepointer,"\n");
    }
    fclose(writepointer);
}
