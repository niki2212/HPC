# MATRIX MULTIPLICATION

## PROJECT MADE BY:
	1. Gauransh Khurana - SE20UCAM041
	2. Karthik MVS - SE20UCSE60
	3. Nikhita Rapolu - SE20UCSE115
	4. Niharika Kakumanu - SE20UCSE114
	5. Neethu Vangapalli - SE20UCSE110

The script loops through all possible combinations asked in the respective questions.
The zip file contains the following files/Folders:

1. Folder named "Threshold":
	A. C file named "file.c" which contains the code
	B. txt files "ot.txt" containing time taken to run the codes with sizes 1024(1) / 2048 (2) / 4096 (3) / 8192 (4)

2. Folder named "Matrix Chain Multiplication":
	A. Shell Script named "MatrixCM.sh"
	B. C file named "MatrixCM.c"
	C. dat file "MatrixCM_Data.dat" containing time taken to run the code with various number of matrices and thread size

3. Folder named "Game of life":
    A. C file named conway2.c which contains the code for the game of life.
	B. C file named "GOL_SeedGenerator.c" which contains the code to generate the seed file.
	C. Shell Script named "GameOfLife.sh" which contains the script to run the code. (It runs both the seed generator and normal file)
	D. 32 .dat files containing inputs and output of different board sizes respectively.
	E. 1 .dat file containing time taken to run all the possibe combinations.

To run the shell script(s)
Run the following in terminal:
	
	chmod u+x FILENAME.sh
	./FILENAME.sh


The script loops through all possible combinations of Threads and Matrix size the problems.
It passes those values as an argument to the C executable

The shell script, in return, takes output from the C files and stores the data in ".dat" files to plot the graphs.


---------------------------------------------------------------------------------------------------------------
Threshold
Arguments: r,c,file name input, p, filename output, number of threads
output: answer in file, time taken printed out
Scanned file, Seen which values [0-300] are 1s and 0s and printed output file with respective B values

---------------------------------------------------------------------------------------------------------------

Matrix Chain Multiplication
Arguments: Number of matrices, Number of threads
Output: Time Taken is present inside the dat file(s)

---------------------------------------------------------------------------------------------------------------

Conways Game of Life
Arguments: SeedFile, row, column, Steps, OutputFile, Number of threads
output: Answer in dat files named "Answer-rownum-colnum", time taken in TimeTaken File.
Scanned file, Applied rules of Conway Game of life "step" number of times and final figure saved in text file.

(We took constant step size of 10 which we can change in the shell script.)
---------------------------------------------------------------------------------------------------------------
