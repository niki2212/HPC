set term pdf size 10,8
set output "Coarse List Plot.pdf"

set xtics (1, 2, 4, 6, 8, 10, 12, 14, 16) font "Bold,10" offset 0, graph 0.01
set ytics font "Bold,7"

set xlabel "Number of Threads" font "Bold,12" offset 0, 0.8
set ylabel "Throughput" font "Bold,12" offset 3,0

set key at screen 0.95,0.95 font ",15" vertical sample 0.4 spacing 0.3 width 0.5 height 1.0 maxrows 1

#------------------------------------------------------------------------------------------------------------------

set multiplot layout 2, 2
set title "Size 2*10^5" font "Bold,15" offset -1.0,-4.2
set size 0.4,0.4
set yrange [0:0.05]

plot "./DataForSize-1.dat" using 1:2 title "100C-0I-0D" with linespoint lw 2 ps 0.25,\
"./DataForSize-1.dat" using 1:3 title "70C-20I-10D" with linespoint lw 2 ps 0.25,\
"./DataForSize-1.dat" using 1:4 title "50C-25I-25D" with linespoint lw 2 ps 0.25,\
"./DataForSize-1.dat" using 1:5 title "30C-35I-35D" with linespoint lw 2 ps 0.25,\
"./DataForSize-1.dat" using 1:5 title "0C-50I-50D" with linespoint lw 2 ps 0.25
unset yrange

#-----------------------------------------------------------------------------------------------------------------

set title "Size 2*10^6" font "Bold,15" offset -1.0,-4.2
set size 0.4, 0.4
set yrange [0:0.05]
plot "./DataForSize-2.dat" using 1:2 title "100C-0I-0D" with linespoint lw 2 ps 0.25,\
"./DataForSize-2.dat" using 1:3 title "70C-20I-10D" with linespoint lw 2 ps 0.25,\
"./DataForSize-2.dat" using 1:4 title "50C-25I-25D" with linespoint lw 2 ps 0.25,\
"./DataForSize-2.dat" using 1:5 title "30C-35I-35D" with linespoint lw 2 ps 0.25,\
"./DataForSize-2.dat" using 1:5 title "0C-50I-50D" with linespoint lw 2 ps 0.25
unset yrange

#-----------------------------------------------------------------------------------------------------------------

set title "Size 2*10^7" font "Bold,15" offset -1.0,-4.2
set size 1, 0.4
set yrange [0:0.05]
plot "./DataForSize-3.dat" using 1:2 title "100C-0I-0D" with linespoint lw 2 ps 0.25,\
"./DataForSize-3.dat" using 1:3 title "70C-20I-10D" with linespoint lw 2 ps 0.25,\
"./DataForSize-3.dat" using 1:4 title "50C-25I-25D" with linespoint lw 2 ps 0.25,\
"./DataForSize-3.dat" using 1:5 title "30C-35I-35D" with linespoint lw 2 ps 0.25,\
"./DataForSize-3.dat" using 1:5 title "0C-50I-50D" with linespoint lw 2 ps 0.25
unset yrange
unset multiplot