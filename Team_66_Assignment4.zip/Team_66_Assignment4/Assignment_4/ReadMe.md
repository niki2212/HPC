# List Implementation
## Project made by:
	1. Karthik MVS - SE20UCSE60
	2. Gauransh Khurana - SE20UCAM041
	3. Neethu Vangapalli - SE20UCSE110
	4. Nikhita Rapolu - SE20UCSE115
	5. Niharika Kakumanu - SE20UCSE114


The zip file contains 4 folders with simulation codes for Coarse list, Fine list, Optimistic list 
and Lazy list implementations with different number of contains, insertion and deletion operation.

A pdf for each implementation contains 3 graphs of throughput vs number of threads
 for sizes 10^5, 10^6 and 10^7 range of the list. Each graph contains 5 lines for different amount
 of contains, insertion and deletion operation possibility.

The data for each implementation is in their respective folder.
**Scales for graph maybe different for different implementations**

To run the shell script(s)
Run the following in terminal:
	
	chmod u+x FILENAME.sh
	./FILENAME.sh

---------------------------------------------------------------------------------------------------------------
Observations:
	Fine grain, Optimistic and Lazy list implementation seem to improve throughput with increasing number of
	threads where as Coarse list does not impact the throughput siginificantly according to the simiulation.
	
	Lazy list had the most increase in throughput with increasing threads, followed by optimistic and fine grain.

	The throughput of implementations with increasing range seemed to decrease the throughput slightly.

	Due to huge amount of time taken to implement, errors can be expected.

	Contains operation takes way less time than insertion and deletion operation which take similar amount of time
---------------------------------------------------------------------------------------------------------------
