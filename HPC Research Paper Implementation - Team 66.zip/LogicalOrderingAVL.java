

import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


interface CompositionalMap<K, V> extends Map<K, V> {
	
    public static final boolean TRAVERSAL_COUNT = false;
    public static final boolean STRUCT_MODS = false;
    
    public class Vars {
    	public long iteration = 0;
    	public long getCount = 0;
    	public long nodesTraversed = 0;
    	public long structMods = 0;
    }
    
    public final static ThreadLocal<Vars> counts = new ThreadLocal<Vars>() {
        @Override
        protected synchronized Vars initialValue() {
            return new Vars();
        }
    };
	
	public V putIfAbsent(K k, V v);

	public void clear();
	
	public int size();
}


public class LogicalOrderingAVL<K, V> extends AbstractMap<K,V> implements ConcurrentMap<K,V>, CompositionalMap<K, V> {


	public static void main(String[] args) {
			
	}

	private AVLMapNode<K,V> root;
	
	private Comparator<? super K> comparator;
	
	private final static Object EMPTY_ITEM = new Object();

	
	public LogicalOrderingAVL() {
		AVLMapNode parent = new AVLMapNode(Integer.MIN_VALUE);
		root = new AVLMapNode(Integer.MAX_VALUE, null, parent, parent, parent);
		root.parent = parent;
		parent.right = root;
		parent.succ = root;
	}
	

	public LogicalOrderingAVL(final K min, final K max) {
		AVLMapNode<K,V> parent = new AVLMapNode<K,V>(min);
		root = new AVLMapNode<K, V>(max, null, parent, parent, parent);
		root.parent = parent;
		parent.right = root;
		parent.succ = root;
	}


	public LogicalOrderingAVL(K min, K max, Comparator<? super K> comparator) {
		this(min, max);
		this.comparator = comparator;
	}
	

	@SuppressWarnings("unchecked")
	private Comparable<? super K> comparable(final Object object) {

		if (object == null) throw new NullPointerException();
		if (comparator == null) return (Comparable<? super K>)object;

		return new Comparable<K>() {
			final Comparator<? super K> compar = comparator;
			final K obj = (K) object;

			public int compareTo(final K other) { 
				return compar.compare(obj, other); 
			}
		};
	}
	

	final public V get(final Object key) {
		final Comparable<? super K> value = comparable(key);

		AVLMapNode<K,V> node = root;
		AVLMapNode<K,V> child;
		K val;
		int res = -1;
		while (true) {
			if (res == 0) break;
			if (res > 0) {
				child = node.right;
			} else {
				child = node.left;
			}
			if (child == null) break;
			node = child;
			val = node.key;
			res = value.compareTo(val);
		}
		while (res < 0) {
			node = node.pred;
			val =  node.key;
			res = value.compareTo(val);
		}
		while (res > 0) {
			node = node.succ;
			val =  node.key;
			res = value.compareTo(val);
		} 
		if (res == 0 && node.valid) {
			return (V) node.item;
		}
		return null;
	}
	

	@Override
	final public boolean containsKey(final Object key) {
		final Comparable<? super K> value = comparable(key);

		AVLMapNode<K,V> node = root;
		AVLMapNode<K,V> child;
		int res = -1;
		K val;
		while (true) {
			if (res == 0) break;
			if (res > 0) {
				child = node.right;
			} else {
				child = node.left;
			}
			if (child == null) break;
			node = child;
			val = node.key;
			res = value.compareTo(val);
		}
		while (res < 0) {
			node = node.pred;
			val =  node.key;
			res = value.compareTo(val);
		}
		while (res > 0) {
			node = node.succ;
			val =  node.key;
			res = value.compareTo(val);
		} 
		return (res == 0 && node.valid);
	}
	

	@Override
	public V put(K key, V value) {
		return insert(key, value, false, false, null);
	}
	

	@Override
	public V putIfAbsent(K key, V value) {
		return insert(key, value, true, false, null);
	}
	

	@Override
	public V replace(K key, V value) {
		return insert(key, value, false, true, EMPTY_ITEM);
	}


	@Override
	public boolean replace(K key, V oldValue, V newValue) {
		return insert(key, newValue, false, true, oldValue).equals(oldValue);
	}


	final private V insert(final K key, final V item, boolean putIfAbsent, boolean isReplace, Object replaceItem) {
		final Comparable<? super K> value = comparable(key);
		AVLMapNode<K,V> node = null;
		K nodeValue = null;
		int res = -1;
		while (true) {
			node = root;
			AVLMapNode<K,V> child;
			res = -1;
			while (true) {
				if (res == 0) break;
				if (res > 0) {
					child = node.right;
				} else {
					child = node.left;
				}
				if (child == null) break;
				node = child;
				nodeValue = node.key;
				res = value.compareTo(nodeValue);
			}
			final AVLMapNode<K,V> pred = res > 0 ? node : node.pred;
			pred.lockSuccLock();
			if (pred.valid) {
				final K predVal = pred.key;
				final int predRes = pred== node? res: value.compareTo(predVal);
				if (predRes > 0) {
					final AVLMapNode<K,V> succ = pred.succ;
					final K succVal = succ.key;
					final int res2 = succ == node? res: value.compareTo(succVal);
					if (res2 <= 0) {
						if (res2 == 0) {
							V item2 = (V) succ.item;
							if (!putIfAbsent && 
									(!isReplace || replaceItem.equals(EMPTY_ITEM) || succ.item.equals(replaceItem))) {
								succ.item = item;
							}
							pred.unlockSuccLock();
							return item2;
						}
						if (isReplace) {
							pred.unlockSuccLock();
							return null;
						}
						final AVLMapNode<K,V> parent = chooseParent(pred, succ, node);
						final AVLMapNode<K,V> newNode = new AVLMapNode<K,V>(key, item, pred, succ, parent);
						succ.pred = newNode;
						pred.succ = newNode;
						pred.unlockSuccLock();
						insertToTree(parent, newNode, parent == pred);
						return null;
					}
				}
			}
			pred.unlockSuccLock();
		}
	}
	

	final private AVLMapNode<K,V> chooseParent(final AVLMapNode<K,V> pred, 
			final AVLMapNode<K,V> succ, final AVLMapNode<K,V> firstCand) {
		AVLMapNode<K,V> candidate = firstCand == pred || firstCand == succ? firstCand: pred;
		while (true) {
			candidate.lockTreeLock();
			if (candidate == pred) {
				if (candidate.right == null) {
					return candidate;
				}
				candidate.unlockTreeLock();
				candidate = succ;
			} else {
				if (candidate.left == null) {
					return candidate;
				}
				candidate.unlockTreeLock();
				candidate = pred;
			}
			Thread.yield();
		}
	}

	final private void insertToTree(final AVLMapNode<K,V> parent, final AVLMapNode<K,V> newNode, final boolean isRight) {
		if (isRight) {
			parent.right = newNode;
			parent.rightHeight = 1;
		} else {
			parent.left = newNode;
			parent.leftHeight = 1;
		}
		if (parent != root) {
			AVLMapNode<K, V> grandParent = lockParent(parent);
			rebalance(grandParent, parent, grandParent.left == parent);
		} else {
			parent.unlockTreeLock();
		}
	}


	final private AVLMapNode<K,V> lockParent(final AVLMapNode<K,V> node) {
		AVLMapNode<K, V> parent = node.parent;
		parent.lockTreeLock();
		while (node.parent != parent || !parent.valid) {
			parent.unlockTreeLock();
			parent = node.parent;
			while (!parent.valid) {
				Thread.yield();
				parent = node.parent;
			}
			parent.lockTreeLock();
		}
		return parent;
	}

	@Override
	final public V remove(final Object key) {
		return remove(key, false, null);
	}
	

	@Override
	final public boolean remove(final Object key, final Object item) {
		return remove(key, true, item) != null;
	}
	

	final public V remove(final Object key, final boolean compareItem, final Object item) {
		Comparable<? super K> value = comparable(key);
		AVLMapNode<K,V> pred, node = null;
		K nodeValue = null;
		int res = 0;
		while (true) {
			node = root;
			AVLMapNode<K,V> child;
			res = -1;
			while (true) {
				if (res == 0) break;
				if (res > 0) {
					child = node.right;
				} else {
					child = node.left;
				}
				if (child == null) break;
				node = child;
				nodeValue = node.key;
				res = value.compareTo(nodeValue);
			}
			pred = res > 0 ? node : node.pred;
			pred.lockSuccLock();
			if (pred.valid) {
				final K predVal = pred.key;
				final int predRes = pred== node? res: value.compareTo(predVal);
				if (predRes > 0) {
					AVLMapNode<K,V> succ = pred.succ;
					final K succVal = succ.key;
					int res2 = succ == node? res: value.compareTo(succVal);
					if (res2 <= 0) {
						if (res2 != 0 || (compareItem && !succ.item.equals(item))) {
							pred.unlockSuccLock();
							return null;
						}
						succ.lockSuccLock();
						AVLMapNode<K,V> successor = acquireTreeLocks(succ);
						AVLMapNode<K, V> succParent = lockParent(succ);
						succ.valid = false;
						V succItem = (V) succ.item;
						AVLMapNode<K, V> succSucc = succ.succ; 
						succSucc.pred = pred; 
						pred.succ = succSucc;
						succ.unlockSuccLock();
						pred.unlockSuccLock();
						removeFromTree(succ, successor, succParent);
						return succItem;
					}
				}
			}
			pred.unlockSuccLock();
		}
	}
	

	final private AVLMapNode<K,V> acquireTreeLocks(final AVLMapNode<K,V> node) {
		while (true) {
			node.lockTreeLock();
			final AVLMapNode<K,V> right = node.right;
			final AVLMapNode<K,V> left = node.left;
			if (right == null || left == null) {
				if (right != null && !right.tryLockTreeLock()) {
					node.unlockTreeLock();
					Thread.yield();
					continue;
				}
				if (left != null && !left.tryLockTreeLock()) {
					node.unlockTreeLock();
					Thread.yield();
					continue;
				}
				return null;
			}

			final AVLMapNode<K,V> successor = node.succ;
			
			final AVLMapNode<K, V> parent = successor.parent;
			if (parent != node) {
				if (!parent.tryLockTreeLock()) {
					node.unlockTreeLock();
					Thread.yield();
					continue;
				} else if (parent != successor.parent || !parent.valid) {
					parent.unlockTreeLock();
					node.unlockTreeLock();
					Thread.yield();
					continue;
				}
			}
			if (!successor.tryLockTreeLock()) { 
				node.unlockTreeLock();
				if (parent != node) parent.unlockTreeLock();
				Thread.yield();
				continue;
			}
			final AVLMapNode<K,V> succRightChild = successor.right; // there is no left child to the successor, perhaps there is a right one, which we need to lock.
			if (succRightChild != null && !succRightChild.tryLockTreeLock()) {
				node.unlockTreeLock();
				successor.unlockTreeLock();
				if (parent != node) parent.unlockTreeLock();
				Thread.yield();
				continue;
			}
			return successor;
		}
	}


	private void removeFromTree(AVLMapNode<K, V> node, AVLMapNode<K, V> succ, 
			AVLMapNode<K, V> parent) {
		if (succ == null) {
			AVLMapNode<K, V> right = node.right;
			final AVLMapNode<K,V> child = right == null ? node.left : right;
			boolean left = updateChild(parent, node, child);
			node.unlockTreeLock();
			rebalance(parent,  child, left);
			return;
		}
		AVLMapNode<K, V> oldParent = succ.parent;
		AVLMapNode<K, V> oldRight = succ.right;
		updateChild(oldParent, succ, oldRight);

		succ.leftHeight = node.leftHeight;
		succ.rightHeight = node.rightHeight;
		AVLMapNode<K, V> left = node.left;
		AVLMapNode<K, V> right = node.right;
		succ.parent = parent;
		succ.left = left;
		succ.right = right; 
		left.parent = succ;
		if (right != null) {
			right.parent = succ;
		}
		if (parent.left == node) {
			parent.left = succ;
		} else {
			parent.right = succ;
		}
		boolean isLeft = oldParent != node;
		boolean violated = Math.abs(succ.getBalanceFactor()) >= 2;
		if (!isLeft) {
			oldParent = succ;
		} else {
			succ.unlockTreeLock();
		}
		node.unlockTreeLock();
		parent.unlockTreeLock();
		rebalance(oldParent, oldRight, isLeft);
		
		if (violated) {
			succ.lockTreeLock();
			int bf = succ.getBalanceFactor();
			if (succ.valid && Math.abs(bf) >=2) {
				rebalance(succ, null, bf >=2? false: true);
			} else {
				succ.unlockTreeLock();
			}
		}
	}


	private boolean updateChild(AVLMapNode<K, V> parent, AVLMapNode<K, V> oldChild,
			final AVLMapNode<K, V> newChild) {
		if (newChild != null) {
			newChild.parent = parent;
		}
		boolean left = parent.left == oldChild;
		if (left) {
			parent.left = newChild;
		} else {
			parent.right = newChild;
		}
		return left;
	}


	final private void rebalance(AVLMapNode<K,V> node, AVLMapNode<K,V> child, boolean isLeft) {
		if (node == root) {
			node.unlockTreeLock();
			if (child != null) child.unlockTreeLock();
			return;
		}
		AVLMapNode<K,V> parent = null;
		try {
			while (node != root) {
				boolean updateHeight = updateHeight(child, node, isLeft);
				int bf = node.getBalanceFactor();
				if (!updateHeight && Math.abs(bf) < 2) return;
				while (bf >= 2 || bf <= -2) {
					if ((isLeft && bf <= -2) || (!isLeft && bf >= 2)) {
						if (child != null) child.unlockTreeLock();
						child = isLeft? node.right : node.left;
						if (!child.tryLockTreeLock()) {
							child = restart(node, parent);
							if (!node.treeLock.isHeldByCurrentThread()) {
								return;
							}
							parent = null;
							isLeft = node.left == child;
							bf = node.getBalanceFactor();
							continue;
						} 
						isLeft = !isLeft;
					}
					if ((isLeft && child.getBalanceFactor() < 0) || (!isLeft && child.getBalanceFactor() > 0)) {
						AVLMapNode<K,V> grandChild =  isLeft? child.right : child.left;
						if (!grandChild.tryLockTreeLock()) {
							child.unlockTreeLock();
							child = restart(node, parent);
							if (!node.treeLock.isHeldByCurrentThread()) {
								return;
							}
							parent = null;
							isLeft = node.left == child;
							bf = node.getBalanceFactor();
							continue;
						}
						rotate(grandChild, child, node, isLeft);
						child.unlockTreeLock();
						child = grandChild;
					}
					if (parent == null) {
						parent = lockParent(node);
					}
					rotate(child,  node, parent, !isLeft);
					bf = node.getBalanceFactor();
					if (bf >= 2 || bf <= -2) {
						parent.unlockTreeLock();
						parent = child;
						child = null;
						isLeft = bf >= 2? false: true; 
						continue;
					}
					AVLMapNode<K, V> temp = child;
					child = node;
					node = temp;
					isLeft = node.left == child;
					bf = node.getBalanceFactor();
				}
				if (child != null) {
					child.unlockTreeLock();
				}
				child = node;
				node = parent != null && parent.treeLock.isHeldByCurrentThread()? parent: lockParent(node);
				isLeft = node.left == child;
				parent = null;
			}
		} finally {
			if (child != null && child.treeLock.isHeldByCurrentThread()) {
				child.unlockTreeLock();
			}
			if (node.treeLock.isHeldByCurrentThread()) node.unlockTreeLock();
			if (parent != null && parent.treeLock.isHeldByCurrentThread()) parent.unlockTreeLock();
		}
	}


	final private AVLMapNode<K,V> restart(AVLMapNode<K,V> node, AVLMapNode<K,V> parent) {
		if (parent != null) {
			parent.unlockTreeLock();
		}
		node.unlockTreeLock();
		Thread.yield();
		while (true) { 
			node.lockTreeLock();
			if (!node.valid) {
				node.unlockTreeLock();
				return null;
			}
			AVLMapNode<K, V> child = node.getBalanceFactor() >= 2? node.left : node.right;
			if (child == null) return null;
			if (child.tryLockTreeLock()) return child;
			node.unlockTreeLock();
			Thread.yield();
		}
	}


	final private boolean updateHeight(AVLMapNode<K,V> child, AVLMapNode<K,V> node, boolean isLeft) {
		int newHeight = child == null? 0: Math.max(child.leftHeight, child.rightHeight) + 1;
		int oldHeight = isLeft? node.leftHeight : node.rightHeight;
		if (newHeight == oldHeight) return false;
		if (isLeft) {
			node.leftHeight = newHeight;
		} else {
			node.rightHeight = newHeight;
		}
		return true;
	}


	final private void rotate(final AVLMapNode<K,V> child, final AVLMapNode<K,V> node, final AVLMapNode<K,V> parent, boolean left) {
		if (parent.left == node) {
			parent.left = child;
		} else {
			parent.right = child;
		}
		child.parent = parent;
		node.parent = child;
		AVLMapNode<K, V> grandChild = left? child.left : child.right;
		if (left) {
			node.right = grandChild;
			if (grandChild != null) {
				grandChild.parent = node; 
			}
			child.left = node;
			node.rightHeight = child.leftHeight;
			child.leftHeight = Math.max(node.leftHeight, node.rightHeight) + 1;
		} else {
			node.left = grandChild;
			if (grandChild != null) {
				grandChild.parent = node; 
			}
			child.right = node;
			node.leftHeight = child.rightHeight;
			child.rightHeight = Math.max(node.leftHeight, node.rightHeight) + 1;
		}
	}
	

	@Override
	public void clear() {
		root.parent.lockSuccLock();
		root.lockTreeLock();
		root.parent.succ = root;
		root.pred = root.parent;
		root.left = null;
		root.leftHeight = 1;
		root.parent.unlockSuccLock();
		root.unlockTreeLock();
	}


	final public int height() {
		return height(root.left);
	}


	final public int height(AVLMapNode<K,V> node) {
		if (node == null) return 0;
		int rMax = height(node.right);
		int lMax = height(node.left);
		return Math.max(rMax, lMax) + 1;
	}


	@Override
	final public int size() {
		return size(root.left);
	}


	final public int size(AVLMapNode<K,V> node) {
		if (node == null) return 0;
		int rMax = size(node.right);
		int lMax = size(node.left);
		return rMax+lMax + 1;
	}
	

	@Override
	public boolean isEmpty() {
		return root.left == null;
	}
	

	@Override
	public Set<java.util.Map.Entry<K, V>> entrySet() {
		return new AbstractSet<Map.Entry<K,V>>() {


			@Override
			public int size() {
				return LogicalOrderingAVL.this.size();
			}

			@Override
			public boolean isEmpty() {
				return LogicalOrderingAVL.this.isEmpty();
			}


			@Override
			public boolean contains(Object o) {
				K key = (K) ((Entry) o).getKey();
				if (((Entry) o).getValue() == null) return false;
				V v = get(key);
				if (v == null) return false;
				return v.equals(((Entry) o).getValue());
			}
			

			@Override
			public boolean add(java.util.Map.Entry<K, V> e) {
				return put(e.getKey(), e.getValue()) != e.getValue();
			}
			

			@Override
			public boolean remove(Object o) {
				return LogicalOrderingAVL.this.remove(((Entry) o).getKey(), ((Entry) o).getValue());
			}
			

			@Override
			public Iterator<java.util.Map.Entry<K, V>> iterator() {
				return new Iterator<Map.Entry<K,V>>() {
					
					private AVLMapNode<K, V> curr = root.parent;
					private AVLMapNode<K, V> currNext = curr;
					
					@Override
					public boolean hasNext() {
						getNext();
						return currNext != root;
					}

					@Override
					public java.util.Map.Entry<K, V> next() {
						getNext();
						curr = currNext;
						return curr == root? null : new SimpleImmutableEntry<K, V>(curr.key, (V) curr.item);
					}

					private void getNext() {
						if (currNext == curr) {
							currNext = curr.succ;
							while (!currNext.valid) currNext = curr.succ;
						}
					}

					@Override
					public void remove() {
						if (curr != root && curr != root.parent)
						LogicalOrderingAVL.this.remove(curr.key, curr.item);
					}
					
				};
			}
			
		};
	}
	
	class AVLMapNode<K,V> {

		public final K key;
		
		public volatile Object item;
		
		public volatile boolean valid;
		
		public volatile AVLMapNode<K, V> pred;
		
		public volatile AVLMapNode<K, V> succ;
		
		final public Lock succLock;

		public volatile AVLMapNode<K, V> parent;
		
		public volatile AVLMapNode<K, V> left;
		
		public volatile AVLMapNode<K, V> right;
		
		public int leftHeight;
		
		public int rightHeight;

		final public ReentrantLock treeLock;


		public AVLMapNode(final K key, final Object item, final AVLMapNode<K, V> pred, final AVLMapNode<K, V> succ, final AVLMapNode<K, V> parent) {
			this.key = key;
			this.item = item;
			valid = true;

			this.pred = pred;
			this.succ = succ;
			succLock = new ReentrantLock();
			
			this.parent = parent;
			right = null;
			left = null;
			leftHeight = 0;
			rightHeight = 0;
			treeLock = new ReentrantLock();
		}
		

		public AVLMapNode(K key) {
			this(key, null, null, null, null);
		}


		public void lockTreeLock() {
			treeLock.lock();
		}


		public boolean tryLockTreeLock() {
			return treeLock.tryLock();
		}

		public void unlockTreeLock() {
			treeLock.unlock();
		}


		public int getBalanceFactor() {
			return leftHeight - rightHeight;
		}


		public void lockSuccLock() {
			succLock.lock();
		}

		public void unlockSuccLock() {
			succLock.unlock();
		}

		@Override
		public String toString() {
			String delimiter = "  ";
			StringBuilder sb = new StringBuilder();

			sb.append("(" + key + delimiter + ", " + valid + ")" + delimiter);

			return sb.append(" [" + leftHeight + ":" + rightHeight + "]").toString();
		}
	}
}
