import java.util.Random;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.ThreadLocalRandom;
import java.util.HashMap;

class CBST_Test{
	private static int RANGE;
	private static int THREADS;
	private static int TIME;
	private static int PRE_FILL;
    private SortedList head;
    private SortedList tail;
    
	CBST instance;
	long []opCount;
	long totalOps;
	Thread []th;
	long start;
	int search_Limit, ins_Limit;
    CBST_Test(int num_threads, int range, int time, int pre_fill, int s_Limit, int i_Limit)
    {
        instance=new CBST();
        THREADS=num_threads;
        RANGE=range;
        TIME=time;
        PRE_FILL=pre_fill;

        th=new Thread[num_threads];
        head=new SortedList(-1);
        tail=head;
        opCount=new long[num_threads];
        totalOps=0;
        search_Limit=s_Limit;
        ins_Limit=i_Limit;
    }
	public void prefill() throws Exception{
			
		Random rd1=new Random();
		for(int i=0;i<1;i++)
		{
			th[i]=new Fill();
		}
		for(int i=0, time=0;i<1;i++)
		{
			th[i].start();
		}
		for(int i=0;i<1;i++)
		{
			th[i].join();
		}
	}

	class Fill extends Thread
	{		 
		int PER_THREAD_PREFILL=RANGE/100*PRE_FILL;
		int int_range=RANGE;
		public void run()
		{
			Random rd1=new Random();
			System.out.println(PER_THREAD_PREFILL);
			for(int i=0;i<PER_THREAD_PREFILL;)
			{
				// System.out.println("In loop");
				//int val=rd1.nextInt(RANGE);
				int val=ThreadLocalRandom.current().nextInt(int_range);
				boolean ins=instance.insert(val);
				if(ins){ i=i+1; }
			}
		
		}
	}

	public void testParallel() throws Exception
	{

		for(int i=0;i<THREADS;i++)
		{
			th[i]=new AllMethods();
		}
		start=System.currentTimeMillis();
		 for(int i=0;i<THREADS;i++)
                {
                        th[i].start();
                }
		 for(int i=0;i<THREADS;i++)
                {
                        th[i].join();
                }
	}
	
	class AllMethods extends Thread
	{
		Random rd1=new Random();
        int range = RANGE;

		public void run()
		{	
			int j = ThreadID.get();
			long count=0;
			boolean incheck=false;
			long end=System.currentTimeMillis();
			int WARMUP_TIME=10000;
			for(;(end-start)<=WARMUP_TIME; end=System.currentTimeMillis())
			{
				int val=ThreadLocalRandom.current().nextInt(RANGE);
				boolean exits=instance.contains(val);
			}
			int cores=Runtime.getRuntime().availableProcessors();
			end=System.currentTimeMillis();
			int TOTAL_TIME=WARMUP_TIME+TIME;
			
			for(;(end-start)<=TIME;)
			{
				
				int ch=0;
				int chVal=ThreadLocalRandom.current().nextInt(99);

				if(chVal<search_Limit){ ch=0; }
				else if((chVal>=search_Limit)&&(chVal<ins_Limit)){ ch=1;}
				else { ch=2;}
				int val=ThreadLocalRandom.current().nextInt(range);
				switch(ch){
					case 0:{
						boolean exits=instance.contains(val);
						} break;
					case 1: {
						if(j>cores){ try{Thread.sleep(0, rd1.nextInt(1000));}catch(Exception e){System.out.println(e);} }
						boolean ins=instance.insert(val);
						}break;
					case 2:{
						if(j>cores){ try{Thread.sleep(0, rd1.nextInt(1000));}catch(Exception e){System.out.println(e);} }
						boolean removed=instance.remove(val); 
						}break;
					default: break;
				}
				count=count+1; 
				  if(count%100==0){ end=System.currentTimeMillis(); }
			}

		}
	}
	public long totalOperations()
	{
		for(int i=0;i<THREADS;i++)
		{
			totalOps=totalOps+opCount[i];
		}
		return totalOps;
	}
	class SortedList
    {
        int key;
        SortedList next;
        public SortedList(int val)
        {
            this.key=val;
            this.next=null;
        }
        public void display()
        {
            int flag=0;
            int count = 0; 
            SortedList node=this;
            node=node.next;
            while(node!=null && node.next!=null)
            {
                if(node.key<node.next.key){ node=node.next; count=count+1;}
                else{ flag=1; break;}
            }
            if(flag==0){ System.out.println("\t:Test_Pass:"+count);} 
            else{ System.out.println("\t:Test_Failed:"+count);} 
        }
    }
    public static void main(String[] args){

        int num_threads=Integer.parseInt(args[0]);
        int range=Integer.parseInt(args[1]);
        int time=Integer.parseInt(args[2]);
        int pre_fill=Integer.parseInt(args[3]);
        int s_Limit=Integer.parseInt(args[4]); 
        int i_Limit=Integer.parseInt(args[5]); 

        CBST_Test ob=new CBST_Test(num_threads, range, time, pre_fill, s_Limit, i_Limit);
        try{ ob.prefill(); }catch(Exception e){ System.out.println(e); }

        try{ ob.testParallel(); }catch(Exception e){ System.out.println(e); }

        long total_Operations=ob.totalOperations();
        double throughput=(total_Operations/(1000000.0*time))*1000;

        System.out.println("c_name:"+ob.instance.getClass().getName()+"\t:num_threads:"+num_threads+"\t:range:"+range+"\t:totalOps:"+total_Operations+" \t:throughput:"+throughput);
    }
}