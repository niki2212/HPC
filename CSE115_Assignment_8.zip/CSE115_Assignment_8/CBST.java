import java.util.Random;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

class CBST
{
    class TNode
    {
        final int key;
        volatile boolean mark;
        volatile TNode left, right, parentNode, pred, succ;
        public ReentrantLock succLock;
        public ReentrantLock treeLock;
        public TNode(int val)
        {
            this.key=val;
            this.mark=false;
            this.left=null;
            this.right=null;
            this.pred=null;
            this.succ=null;
            this.succLock=new ReentrantLock();
            this.treeLock=new ReentrantLock();
        }
        void treeLock() { treeLock.lock(); }
        void treeUnlock() { treeLock.unlock(); }
        boolean tryLock() {return treeLock.tryLock(); }
        void succLock() { succLock.lock(); }
        void succUnlock(){ succLock.unlock();}
        boolean trySuccLock() { return succLock.tryLock(); }
    }

    public TNode rootNode;
    public CBST()
    {
        rootNode=new TNode(Integer.MAX_VALUE);
        rootNode.left=new TNode(Integer.MIN_VALUE);
        rootNode.left.parentNode=rootNode;
        rootNode.left.succ=rootNode;
        rootNode.pred=rootNode.left;
    }

    public TNode Search_CBST(int val) {
        TNode node = rootNode, childNode;
        while (true) {
            int currKey = node.key;
            if(currKey == val)  return node;
            childNode = currKey<val?node.right:node.left;
            if(childNode == null)   return node;
            node = childNode;
        }
    }  
    public boolean Contains_CBST(int val)
    {
        TNode node = Search_CBST(val);
        while(node.key>val){ node = node.pred; }
        while(node.key<val) { node = node.succ; }
        if(node.key == val)
        {
            return (!node.mark);
        }
        return false;
    }
    public boolean Insert_into_CBST(TNode predecessor, TNode successor, TNode node, int val)
    {
        TNode newNode;
        if(((val<node.key)&&(node.left == null))||((val>node.key)&&(node.right==null)))
        {
            newNode = new TNode(val);
            newNode.parentNode = node;
            newNode.succ = successor;
            newNode.pred = predecessor;
            successor.pred = newNode;
            predecessor.succ = newNode;
            predecessor.succUnlock();
            if(val<node.key){
                node.left = newNode;
            }
            else{
                node.right = newNode;
            }
            node.treeUnlock();
            return true;
        }
        return false;
    }

    public boolean remove(int val) {
        while (true) {
            TNode node, predecessor, successor, sSuccessor;
            boolean Has_Two_Children;
            node = Search_CBST(val);
            predecessor = (node.key >= val) ? node.pred : node;
            if (!predecessor.trySuccLock()) { continue; }
            successor = predecessor.succ;
            if ((!predecessor.mark) && (!successor.mark) && (val > predecessor.key) && (val <= successor.key)) {
                
                if (val < successor.key) {
                    predecessor.succUnlock();
                    return false;
                } 
            else {
                    successor.mark = false;
                    while (!successor.trySuccLock()) { }
                    Has_Two_Children = TreeLockAcquire(successor);
                    successor.mark = true;
                    sSuccessor = successor.succ;
                    sSuccessor.pred = predecessor;
                    predecessor.succ = sSuccessor;
                    successor.succUnlock();
                    predecessor.succUnlock();
                    removeFromTree(successor, Has_Two_Children);
                return true;
                }   
            }
        }
    }

    public void removeFromTree(TNode n, boolean Has_Two_Children)
    {
        if(!Has_Two_Children)
        {
            OneChildRemoveFromTree(n);
        }
        else{
            TwoChildRemoveFromTree(n);
        }
    }

    public void updateChild(TNode parentNode, TNode node, TNode childNode)
    {
        if(parentNode.left==node){parentNode.left=childNode;}
        else{parentNode.right=childNode;}
        if(childNode!=null){childNode.parentNode=parentNode;}
    }

    public boolean insert(int val)
    {
        while(true){
            TNode node, predecessor, successor, newNode, parentNode;
            node = Search_CBST(val);
            predecessor = (node.key>=val)? node.pred:node;
            if(!predecessor.trySuccLock()){ continue; }
            successor = predecessor.succ;
            if((!predecessor.mark)&&((val>predecessor.key)&&(val<=successor.key)))
            {

                if(predecessor.key == val)
                {
                    predecessor.succUnlock();
                    return false;
                }
                else{
                    if(!node.tryLock())
                    {
                        predecessor.succUnlock();
                        continue;
                    }
                    if(node.mark)
                    {
                        predecessor.succUnlock();
                        node.treeUnlock();
                        continue;
                    }
                    boolean flag = Insert_into_CBST(predecessor,successor,node,val);
                    if(flag == true) { return true; }
                    else
                    {
                        node.treeUnlock();
                        predecessor.succUnlock();
                        continue;
                    }
                }
            }
            else{ predecessor.succUnlock();}
        }
    }

    public boolean TreeLockAcquire(TNode n) 
    {
        while (true) {
            TNode successor, nparentNode;
            if (!n.tryLock()) {
                continue;
            }
            nparentNode = n.parentNode;
            if (!nparentNode.tryLock()) {
                n.treeUnlock();
                continue;
            }
            if (nparentNode != n.parentNode || nparentNode.mark) {
                nparentNode.treeUnlock();
                n.treeUnlock();
                continue;
            }
    
            if (n.right == null || n.left == null) {
                boolean flag = OneChildAcquireFromTree(n);
                if (flag) {
                    return false;
                } else {
                    nparentNode.treeUnlock();
                    n.treeUnlock();
                    continue;
                }
            } else {

                boolean flag = TwoChildAcquireFromTree(n);
                if (flag) {
                    return true;
                } else {
                    nparentNode.treeUnlock();
                    n.treeUnlock();
                    continue;
                }
            }
        }
    }

    public boolean OneChildAcquireFromTree(TNode n)
    {
        if (n.right != null)
        {
            if (!n.right.tryLock())
            {
                n.parentNode.treeUnlock();
                n.treeUnlock();
                return false;
            }
        }
        else if (n.left != null)
        {
            if (!n.left.tryLock())
            {
                n.parentNode.treeUnlock();
                n.treeUnlock();
                return false;
            }
        }
        return true;
    }

    public boolean TwoChildAcquireFromTree(TNode n)
    {
        TNode predecessor, successor, left, right;
        while (true)
        {
            predecessor = n.left;
            successor = n.right;
    
            if (predecessor.tryLock())
            {
                if (successor.tryLock())
                {
                    left = n.left;
                    right = n.right;
    
                    if (n.left == left && n.right == right && !n.mark && !predecessor.mark && !successor.mark)
                    {
                        return true;
                    }
    
                    successor.treeUnlock();
                }
    
                predecessor.treeUnlock();
            }
    
            if (n.parentNode != null && !n.parentNode.tryLock())
            {
                return false;
            }
        }
    }
    

    public void OneChildRemoveFromTree(TNode n)
    {
        TNode childNode=null, parentNode;
        parentNode = n.parentNode;

        if(n.left!=null)
        {
            updateChild(parentNode, n, n.left);
            n.left.treeUnlock();

        }
        else if(n.right!=null)
        {
            updateChild(parentNode, n, n.right);
            n.right.treeUnlock();
        }
        else{
            updateChild(parentNode, n, childNode);
            
        }
        parentNode.treeUnlock();
        n.treeUnlock();
    }

    public TNode getInorderSuccessor(TNode node) 
    {
        if (node.right != null) {
            TNode curr = node.right;
            while (curr.left != null) {
                curr = curr.left;
            }
            return curr;
        } 
        else {
            TNode parentNode = node.parentNode;
            while (parentNode != null && node == parentNode.right) {
                node = parentNode;
                parentNode = parentNode.parentNode;
            }
            return parentNode;
        }
    }

    public void TwoChildRemoveFromTree(TNode n) 
    {
        TNode inorderSucc = getInorderSuccessor(n);
        TNode childNode = (inorderSucc.left != null) ? inorderSucc.left : inorderSucc.right;

        if (childNode != null) {
            childNode.parentNode = inorderSucc.parentNode;
        }

        if (inorderSucc.parentNode == n) {
            n.left = childNode;
            n.right = inorderSucc.right;
        
            inorderSucc.right.parentNode = n;
            n.treeUnlock();
            inorderSucc.treeUnlock();
            return;
        }

        if (inorderSucc.left == null && inorderSucc.right == null) {
            if (inorderSucc.parentNode.left == inorderSucc) {
                inorderSucc.parentNode.left = null;
            } else {
                inorderSucc.parentNode.right = null;
            }
            n.treeUnlock();
            inorderSucc.treeUnlock();
            return;
        }

        if (inorderSucc.right != null) {
            inorderSucc.right.parentNode = inorderSucc.parentNode;
        }

        inorderSucc.parentNode.left = inorderSucc.right;

        n.treeUnlock();
        inorderSucc.treeUnlock();
        }
    }