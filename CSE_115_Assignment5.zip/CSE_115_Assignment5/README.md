
Nikhita Rapolu
SE20UCSE115

--------------------------------------------------------------------------------------------------------------------

PetersonLock.java` has two functions, lock() and unlock().
The code in Main.java tests the implementation of Peterson's lock by creating a shared variable called "counter" which is incremented by one thread (t1) and decremented by another thread (t2). The program is executed multiple times with different input values, and each time the program finishes executing, the value of the counter should always be 0. If the program outputs "PASS", it means that the implementation of the lock is working successfully, and the test has passed for all the different input values that were used.

To execute: 

'javac Main.java'
'java Main'

--------------------------------------------------------------------------------------------------------------------