import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.ThreadLocalRandom;

public final class LazySkipList {
    private final int maxLevel;
    private final Node head;
    private final Node tail;
    private final Lock lock = new ReentrantLock();

    public LazySkipList() {
        this(31);
    }

    public LazySkipList(final int maxLevel) {
        this.maxLevel = maxLevel;
        this.head = new Node(Integer.MIN_VALUE, maxLevel);
        this.tail = new Node(Integer.MAX_VALUE, maxLevel);
        for (int i = 0; i <= maxLevel; i++) {
            head.next[i] = tail;
        }
    }

    public boolean contains(final int value) {
        Node[] preds = (Node[]) new Node[maxLevel + 1];
        Node[] succs = (Node[]) new Node[maxLevel + 1];
        int levelFound = find(value, preds, succs);
        return (levelFound != -1 && !succs[levelFound].marked);
    }

    public boolean add(int value) {
        int topLevel = randomLevel();
        Node[] preds = (Node[]) new Node[maxLevel + 1];
        Node[] succs = (Node[]) new Node[maxLevel + 1];
        while (true) {
            int levelFound = find(value, preds, succs);
            if (levelFound != -1) {
                Node nodeFound = succs[levelFound];
                if (!nodeFound.marked) {
                    while (!nodeFound.fullyLinked) {
                        // Help another thread complete the linking process
                        Thread.yield();
                    }
                    return false;
                }
                continue;
            }
            int highestLocked = -1;
            try {
                Node pred, succ;
                boolean valid = true;
                for (int level = 0; valid && (level <= topLevel); level++) {
                    pred = preds[level];
                    succ = succs[level];
                    pred.lock();
                    highestLocked = level;
                    valid = !pred.marked && !succ.marked && pred.next[level] == succ;
                }
                if (!valid) {
                    continue;
                }
                Node newNode = new Node(value, topLevel);
                for (int level = 0; level <= topLevel; level++) {
                    newNode.next[level] = succs[level];
                }
                for (int level = 0; level <= topLevel; level++) {
                    preds[level].next[level] = newNode;
                }
                newNode.fullyLinked = true; // Mark the new node as fully linked
                return true;
            } finally {
                // Unlock all previously locked nodes
                for (int level = 0; level <= highestLocked; level++) {
                    preds[level].unlock();
                }
            }
        }
    }

    public boolean remove(int value) {
        Node[] preds = (Node[]) new Node[maxLevel + 1];
        Node[] succs = (Node[]) new Node[maxLevel + 1];
        Node nodeToDelete = null;
        int topLevel = -1;
        while (true) {
            int levelFound = find(value, preds, succs);
            if (levelFound != -1) {
                Node nodeFound = succs[levelFound];
                if (nodeToDelete == null) {
                    nodeToDelete = nodeFound;
                    topLevel = levelFound;
                    nodeToDelete.lock();
                    if (nodeToDelete.marked) {
                        nodeToDelete.unlock();
                        return false;
                    }
                }
                // Mark all levels of the node for deletion
                for (int level = topLevel; level >= 0; level--) {
                    preds[level].next[level] = nodeToDelete.next[level];
                }
                nodeToDelete.marked = true; // Mark the node as deleted
                nodeToDelete.unlock();
                return true;
            } else {
                return false;
            }
        }
    }

    private int randomLevel() {
        int level = 0;
        while (ThreadLocalRandom.current().nextDouble() < 0.5 && level < maxLevel) {
            level++;
        }
        return level;
    }

    private int find(int value, Node[] preds, Node[] succs) {
        int levelFound = -1;
        Node pred = head;
        for (int level = maxLevel; level >= 0; level--) {
            Node curr = pred.next[level];
            while (value > curr.value) {
                pred = curr;
                curr = pred.next[level];
            }
            if (levelFound == -1 && value == curr.value) {
                levelFound = level;
            }
            preds[level] = pred;
            succs[level] = curr;
        }
        return levelFound;
    }

    private static final class Node {
        private final int value;
        private final Node[] next;
        private volatile boolean marked;
        private volatile boolean fullyLinked;
        private final Lock lock;

        Node(int value, int level) {
            this.value = value;
            this.next = new Node[level + 1];
            this.marked = false;
            this.fullyLinked = false;
            this.lock = new ReentrantLock();
        }

        void lock() {
            lock.lock();
        }

        void unlock() {
            lock.unlock();
        }
    }
}

