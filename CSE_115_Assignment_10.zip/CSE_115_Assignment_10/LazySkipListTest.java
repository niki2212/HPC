import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.ThreadLocalRandom;
import java.util.HashMap;

public class LazySkipListTest {
    private static int THREADS;
    private static int TIME;
    private static int PRE_FILL;
    private static int INSERT_LIMIT;
    private static int SEARCH_LIMIT;
    LazySkipList instance;
    long[] opCount;
    long totalOps;
    Thread[] th;
    long start;

    public LazySkipListTest(int numThreads, int time, int preFill, int insertLimit, int searchLimit) {
        instance = new LazySkipList();
        THREADS = numThreads;
        TIME = time;
        PRE_FILL = preFill;
        INSERT_LIMIT = insertLimit;
        SEARCH_LIMIT = searchLimit;
        th = new Thread[numThreads];
        opCount = new long[numThreads];
        totalOps = 0;
    }

    public void testParallel() throws Exception {
        for (int i = 0; i < THREADS; i++) {
            th[i] = new AllMethods();
        }
        start = System.currentTimeMillis();
        for (int i = 0; i < THREADS; i++) {
            th[i].start();
        }
        for (int i = 0; i < THREADS; i++) {
            th[i].join();
        }
    }

    class AllMethods extends Thread {
        public void run() {
            int j = ThreadID.get();
            long count = 0;
            long end = System.currentTimeMillis();
            while ((end - start) <= TIME) {
                int operation;
                if (count < PRE_FILL) {
                    // Pre-fill phase: insert operation
                    operation = 1;
                } else {
                    // Main phase: randomly select operation (0: contains, 1: insert, 2: remove)
                    operation = ThreadLocalRandom.current().nextInt(3);
                }

                int value = ThreadLocalRandom.current().nextInt(INSERT_LIMIT); // Randomly generate a value

                switch (operation) {
                    case 0:
                        if (value < SEARCH_LIMIT) {
                            instance.contains(value);
                            count++;
                        }
                        break;
                    case 1:
                        instance.add(value);
                        count++;
                        break;
                    case 2:
                        instance.remove(value);
                        count++;
                        break;
                }

                if (count % 100 == 0) {
                    end = System.currentTimeMillis();
                }
            }
            opCount[j] = count;
            System.out.println("Thread " + j + " final count: " + count);
        }
    }

    public long totalOperations() {
        for (int i = 0; i < THREADS; i++) {
            totalOps = totalOps + opCount[i];
        }
        return totalOps;
    }

    public static void main(String[] args) {
        int numThreads = Integer.parseInt(args[0]);
        int time = Integer.parseInt(args[1]);
        int preFill = Integer.parseInt(args[2]);
        int insertLimit = Integer.parseInt(args[3]);
        int searchLimit = Integer.parseInt(args[4]);

        LazySkipListTest ob = new LazySkipListTest(numThreads, time, preFill, insertLimit, searchLimit);
        try {
            ob.testParallel();
        } catch (Exception e) {
            System.out.println(e);
        }
        long totalOperations = ob.totalOperations();
        double throughput = (totalOperations / (1000000.0 * time)) * 1000; // Millions of Operations per second
        System.out.print("numThreads: " + numThreads + " totalOps: " + totalOperations + " throughput: " + throughput + "\n");
    }
}

class ThreadID {
    private static volatile int nextID = 0;
    private static ThreadLocal<Integer> threadID = new ThreadLocal<Integer>() {
        protected synchronized Integer initialValue() {
            return nextID++;
        }
    };

    public static int get() {
        return threadID.get();
    }
}

