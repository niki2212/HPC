import java.util.concurrent.locks.Lock;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.*;


public class TASbackoff{
    private AtomicBoolean state = new AtomicBoolean(false);
    private static final int MIN_DELAY = 500;
    private static final int MAX_DELAY = 1000;

    public void lock(){
        Backoff backoff = new Backoff(MIN_DELAY,MAX_DELAY);
        while(true){
            while(state.get()){};
            if(!state.getAndSet(true)){
                return;
            }
            else{
                try{
                backoff.backoff();
                }
                catch(Exception e){
                }
            }
        }
    }
    public void unlock(){
        state.set(false);
    }
    public class Backoff{
        final int minDelay, maxDelay;
        int limit;
        public Backoff(int min,int max){
            minDelay = min;
            maxDelay = max;
            limit = minDelay;
        }
        public void backoff() throws InterruptedException{
            int delay = ThreadLocalRandom.current().nextInt(limit);
            limit = Math.min(maxDelay,2*limit);
            Thread.sleep(delay);
        }
    }
}