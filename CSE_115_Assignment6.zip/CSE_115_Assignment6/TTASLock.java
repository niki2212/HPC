import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class TTASLock {
private boolean state[] = { false, false };
private Lock lock = new ReentrantLock();

public void inc() {
    int mySlot = ThreadID.get();
    int otherSlot = 1 - mySlot;
    boolean wasSet = false;
    while (!wasSet) {
        lock.lock();
        try {
            if (!state[otherSlot]) {
                state[mySlot] = true;
                wasSet = true;
            }
        } finally {
            lock.unlock();
        }
    }
    lock.lock();
    try {
    } finally {
        state[mySlot] = false;
        lock.unlock();
    }
}
}