import java.util.Random;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.ThreadLocalRandom;
import java.util.HashMap;

public class Lock_test {
    private static int THREADS;
    private static int TIME;
    TASLock instance;
    // TTASLock instance;
    // TASBackoff instance;
    long[] opCount;
    long totalOps;
    Thread[] th;
    long start;

    public Lock_test(int num_threads, int time) {
        instance = new TASLock();
        // instance = new TTASLock();
        // instance = new TASBackoff();
        THREADS = num_threads;
        TIME = time;
        th = new Thread[num_threads];
        opCount = new long[num_threads];
        totalOps = 0;
    }

    public void testParallel() throws Exception {

        for (int i = 0; i < THREADS; i++) {
            th[i] = new AllMethods();
        }
        start = System.currentTimeMillis();
        for (int i = 0; i < THREADS; i++) {
            th[i].start();
        }
        for (int i = 0; i < THREADS; i++) {
            th[i].join();
        }
    }

    class AllMethods extends Thread {
        int pri_range = Integer.MAX_VALUE - 10;
        public void run() {
            int j = ThreadID.get();
            long count = 0;
            long end = System.currentTimeMillis();
            for (int i = 0; (end - start) <= TIME; i = i + 1) {
                instance.inc();
                count = count + 1;
                if (count % 100 == 0) {
                    end = System.currentTimeMillis();
                }
            }
            opCount[j] = count;
            System.out.println("Thread " + j + " final count: " + count);
        }
    }

    public long totalOperations() {
        for (int i = 0; i < THREADS; i++) {
            totalOps = totalOps + opCount[i];
        }
        return totalOps;
    }

    void display() {
        
    }

    public static void main(String[] args) {
        int num_threads = Integer.parseInt(args[0]);
        int time = Integer.parseInt(args[1]);
        Lock_test ob = new Lock_test(num_threads, time);
        try {
            ob.testParallel();
        } catch (Exception e) {
            System.out.println(e);
        }
        long total_Operations = ob.totalOperations();
        double throughput = (total_Operations / (1000000.0 * time)) * 1000; 
        System.out.print("c_name:" + ob.instance.getClass().getName() + " :num_threads:" + num_threads
                + " :totalOps:" + total_Operations + " :throughput:" + throughput + "\n");
    }
}

class ThreadID {
    private static volatile int nextID = 0;
    private static ThreadLocal<Integer> threadID = new ThreadLocal<Integer>() {
        protected synchronized Integer initialValue() {
            return nextID++;
        }
    };

    public static int get() {
        return threadID.get();
    }
}

