import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class TASLock {
    private boolean state = false;
    private Lock lock = new ReentrantLock();

    public void inc() {
        boolean set = false;
        while (!set) {
            lock.lock();
            try {
                if (!state) {
                    state = true;
                    set = true;
                }
            } finally {
                lock.unlock();
            }
        }
        lock.lock();
        try {
        } finally {
            state = false;
            lock.unlock();
        }
    }
}

